  .-------------------------------.
  |  PROACTIVE COMPUTER SECURITY  |
  |    Week 3: Reversing          |
  |      Weekly assignment        |
  |     Tudor Dragan xlq880       |
  '-------------------------------'

For this assignment I did the first 3 phases and commented out the 4th.
I couldn't find the right number for phase 4, though.
I think I wrote decent enough comments in the asssembly dump `bomb.dump` so that the attacker could undestand what the phases do.
Solutions are in the `solutions.txt` file.

